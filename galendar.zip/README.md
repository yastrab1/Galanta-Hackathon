<p align="center">
	<a href="https://kockatykalendar.sk/">
		<img src="https://user-images.githubusercontent.com/11409143/100661141-4b168000-3353-11eb-8ef9-5be050a0d743.png" width="800" height="438">
		<h1 align="center">Galendár</h1>
	</a>
	<p align="center">Prehľad akcií a súťaží v oblasti matematiky, fyziky a informatiky pre základné a stredné školy. </p>
</p>


## O projekte

Na Slovensku existuje množstvo organizácií ponúkajúcich súťaže a akcie pre základoškolákov alebo stredoškolákov v oblasti matematiky, fyziky a informatiky. Súťaží a akcií je tak veľa, že môže byť zložité vyznať sa vo všetkých.

Galendár je spoločná iniciatíva týchto organizácií, ktorá ponúka jednoduchý, jasný a pochopiteľný prehľad organizovaných súťaží.


## Kontakt

Ak si našiel/-la chybu alebo máš otázku, napíš nám na kockaty.kalendar@p-mat.sk a my sa ti ozveme.


